#to store sensitive information as follows:
DEBUG = True #host validation is disabled, if there's error page will show details of error
MY_API_KEY = "7e5019bfda276137c299a5ce6f68325d"
#not a publicly available REST API so requires authentication using direct API-API_KEY
#API Keys are uniquely generated value assigned to each first time user (user is known)
