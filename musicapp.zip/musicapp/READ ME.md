The Official Top 10 App

Compare top 10 songs listed on the Country Charts worldwide

#source of API:www.musixmatch.com

Just key in your country of interest to get
the list of top 10 songs.

Charts available for:
UK - United Kingdom
US - United States
AU - Australia
NZ - New Zealand
FR - France
IT - Italy
CF - Switzerland

Compare the top 10 charts of 2 countries as follows:
http://127.0.0.1:8080/?countryA=nz&countryB=au

You can also choose choose WX - Worldwide for worldwide chart!
